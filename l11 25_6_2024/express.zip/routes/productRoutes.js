const router = require("express").Router()

router.post("/addProduct",()=>{

})





module.exports = router;